Ximera Activities for Introduction to the Mathematics Major
===========================================================

These activites are supposed to help potential math majors.

They are available at ximera.osu.edu
