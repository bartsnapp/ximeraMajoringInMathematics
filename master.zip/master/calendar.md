Calendar for 1295
=================

* Card eating problem

* Euler Characteristic

* Interest and where your payment goes.
  (If we could tell this story well, that would be really great)
